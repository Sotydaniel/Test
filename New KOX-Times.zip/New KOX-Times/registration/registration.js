
function emptyFieldAlert(message) {
    // Get the snackbar DIV
    let snackbar = document.getElementById("empty-field-alert");
  
    // Add the "show" class to DIV
  
    snackbar.className = "show";
    snackbar.textContent = "";
    snackbar.textContent = message;
  
    redirectToSignin = true;
  
    // After 3 seconds, remove the show class from DIV
    setTimeout(function () {
      snackbar.className = snackbar.className.replace("show", "");
    }, 3000);
  }
function saveData(){
    let firstname, lastname, othername, password,email,address;
    firstname =document.getElementById("firstname").value;
    lastname =document.getElementById("lastname").value;
    othername =document.getElementById("othername").value;
    email =document.getElementById("email").value;
    password =document.getElementById("password").value;
    username=document.getElementById("username").value;
    address=document.getElementById("address").value;
    
    
    //localStorage.setItem("firstname",firstname);
    //localStorage.setItem("lastname",lastname);
    //localStorage.setItem("othername",othername);
    //localStorage.setItem("password",password);
    //localStorage.setItem("email",email);
    //localStorage.setItem("username",username)

    let user_record =new Array();
    user_record=JSON.parse(localStorage.getItem("users"))?JSON.parse(localStorage.getItem("users")):[]
    if(user_record.some((v)=>{
        return v.email==email
    })){
        // alert("Email already in use")
        emptyFieldAlert("Email already in use")
        
    }
    else{
        user_record.push({
            "firstname":firstname,
            "lastname":lastname,
            "othername":othername,
            "email":email,
            "password":password,
            "username":username,
            "address":address
            
        })
        localStorage.setItem("users",JSON.stringify(user_record))
        window.location.href="login.html"
        
    }
    if(firstname.value === "" || firstname.value===null){
        messages.push('First name is required')
    }
    if (messages.length > 0){
        e.preventDefault()
        errorElement.innerText = messages.join(', ')
        }
        
 }

 