<script>
      let searchBar = document.getElementById('search-item');
    
      searchBar.addEventListener('input', (v) => {
       let searchValue = v.target.value.toLowerCase();
    
      let searchtitles = document.querySelectorAll('h3');
    
      //console.log(searchtitles);
    
      let searchItems = document.querySelectorAll('.card1');
    
      console.log(searchItems);
    
      for (let i =0; i < searchItems.length; i++) {
        let item = searchItems[i];
    
        let itemTitle  = searchtitles[i].innerText.toLowerCase();
        //item.style.display = 'flex';
        if (itemTitle.includes(searchValue)) {
          item.classList.remove('none');
          item.classList.add('flex');
        }
        else {
          item.classList.remove('flex');
          item.classList.add('none');
        }
      }
      });
      
    
    </script>


    <div class="card">
      <div class="card-left blue-bg">
        <img src="image/total.png" alt="">
      </div>
      <div class="card-center">
        <h3 class="comp-title">Total</h3>
        <p class="card-detail">Petroleum engineer</p>
        <p class="class-loc"><ion-icon name="location-outline"> </ion-icon>total rd</p>
        <div class="card-sub">
          <p><ion-icon name="today-outline"></ion-icon>20 min ago </p>
          <p><ion-icon name="hourglass-outline"></ion-icon> Full-time</p>
          <p><ion-icon name="people-outline"></ion-icon>100 Applicants </p>
        </div>
      </div>
      <div class="card-right">
        <div class="card-tag">
          <h5>Division</h5>
          <a href="#">Petroleum engineer</a>
        </div>
        <div class="card-salary">
          <p><b>$20</b><span>/month</span></p>
          <p> More details</p>
        </div>
      </div>
      <div class="card-right1">

<div class="main">
  <div class="main-header">
    <ion-icon class="menu-bar" name="menu-outline"></ion-icon>
    <div class="search">
      <input type="text" placeholder="search your it listing here... " id="search-item">
      <div id="results"></div>
      <button class="btn-search" ><ion-icon name="search-outline"></ion-icon> </button>
    </div>
  </div>
       