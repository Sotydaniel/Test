

let cartIcon = document.getElementById('cart-icon');
let Cart = document.querySelector('.cart');
let closeCart = document.querySelector('#close-cart');


cartIcon.onclick = () => {
	Cart.classList.add('active');
}
closeCart.onclick = () => {
	Cart.classList.remove('active');
}



// cart wor

if (document.readyState == 'loading') {
	document.addEventListener('DOMContentLoaded',ready)
}else{
	ready();
}

// making functionality
function ready() {
	var removeCartButtons = document.getElementsByClassName('cart-remove')
	console.log(removeCartButtons)
	for (var i = 0; i < removeCartButtons.length; i++) {
		var button = removeCartButtons[i]
		button.addEventListener('click', removeCartItem)
	}
	// quantity changes
	let quantityInputs = document.getElementsByClassName('cart-quantity');
	for (i = 0; i < quantityInputs.length; i++) {
		let input = quantityInputs[i];
		input.addEventListener('change', quantityChanged);
	}
	// add to cart
	let addCart = document.querySelectorAll('.addcart');
	for (var i = 0; i < addCart.length; i++) {
		var button = addCart[i];
		button.addEventListener('click', addCartClicked);
	}
}

function removeCartItem(event){
	let buttonClicked = event.target;
	buttonClicked.parentElement.remove();
	updateTotal();
}
// quantity change
function quantityChanged(event){
	let input = event.target
	if (isNaN(input.value) || input.value <= 0){
		input.value = 1;
	}
	updateTotal();
}
// add to cart
function addCartClicked(event){
	let button = event.target;
	let shopProducts = button.parentElement;
	let title = shopProducts.getElementsByClassName('name-tag')[0].innerText;
	let price = shopProducts.getElementsByClassName('price')[0].innerText;
	let productImage = shopProducts.getElementsByClassName('img')[0].src;
	
	addProductToCart(title, price, productImage);
	updateTotal();
	
}
function addProductToCart(title, price, productImage) {
	let cartShopBox = document.createElement('div');
	cartShopBox.classList.add('cart-box');
	let cartItems = document.getElementsByClassName('cart-content')[0]
	let cartItemsNames = cartItems.getElementsByClassName('cart-product-title');
	for (let i = 0; i < cartItemsNames.length; i++){
		// alert('you have already added this item to the cart');
		
		return;
	}
	
}
let cartBoxContent = 
				`<img src="./watch image/OIP (1).jpeg" alt="" class="cart-image">
                <div class="details-box">
                    <div class="cart-product-title">Rolex</div>
                    <div class="cart-price">$200.04</div>
                    <input type="number" value="1" class="cart-quantity">
                    
                </div>
                <!-- remove item -->
                <i class='bx bx-trash cart-remove' ></i>`;
				
cartShopBox.innerHTML = cartBoxContent;
cartItems.append(cartShopBox);
cartShopBox.getElementsByClassName('cart-remove')[0].addEventListener('click',removeCartItem);
cartShopBox.getElementsByClassName('cart-quantity')[0].addEventListener('change',quantityChanged);




// update total
function updateTotal(){
	var cartContent = document.getElementsByClassName('cart-content')[0];
	var cartBoxes = cartContent.getElementsByClassName('cart-box');
	var total = 0;
	for (var i = 0; i < cartBoxes.length; i++) {
		var cartBox = cartBoxes[i];
		var priceElement = cartBox.getElementsByClassName('cart-price')[0];
		var quantityElement = cartBox.getElementsByClassName('cart-quantity')[0];
		var price = parseFloat(priceElement.innerText.replace('$', ''));
		var quantity = quantityElement.value;
		total = total + (price * quantity);
		// if price contains a floating point number
		total = Math.round(total * 100)/100;

		document.getElementsByClassName('total-price')[0].innerHTML = '$' + total;
	}
}